from server_wrapper import run_server

if __name__ == "__main__":
    print("Starting WellConnect API Server...")
    run_server(port=8090) 